#!/bin/bash
./run.sh
coqc Introduction.v
coqc Example.v
coqdoc --html --interpolate --lib-subtitles -s --no-index Introduction.v Section3_Requirements.v Section3_Infrastructure.v Section3_Proofs.v Section4_Requirements.v Section4_Infrastructure.v Section4_Proofs.v Section5.v Example.v
coqdoc --html --interpolate --lib-subtitles -s -l -o index.html Introduction.v Section3_Requirements.v Section3_Proofs.v Section4_Requirements.v Section4_Proofs.v Section5.v
rm coqdoc.css
cp mycoqdoc.css coqdoc.css
