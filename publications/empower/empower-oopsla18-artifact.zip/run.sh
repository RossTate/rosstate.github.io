#!/bin/bash
coqc Util.v
coqc Section3_Requirements.v
coqc Section3_Infrastructure.v
coqc Section3_Proofs.v
coqc Section4_Requirements.v
coqc Section4_Infrastructure.v
coqc Section4_Proofs.v
coqc Section5.v
