This is not the artifact that was evaluated during the OOPSLA 2018 Artifact Evaluation process, rather it is an improvement on that artifact.
For archival purposes, the outdated artifact that was evaluated is provided in outdated_artifact.zip.
However, the outdated artifact does not directly support the claims stated in the paper, and the section of the paper that discussed what claims it did support has been removed, so we strongly discourage referencing the outdated artifact.
The artifact presented here, although it was not evaluated, has been developed to the same or higher quality than the one that was, and was made to directly support the claims in the paper.

Open index.html in a browser of your choice to read an overview of the Coq formalization.
Otherwise, go through the .v files in the following order:
Section3_Requirements.v
Section3_Proofs.v
Section4_Requirements.v
Section4_Proofs.v
Section5.v

You may also inspect Util.v, Section3_Infrastructure.v, and Section4_Infrastructure.v, but they mostly contain rather straightforward utility Definitions and Lemmas.
Finally, Example.v contains an example of how to instantiate the requirement modules for Sections 3 and 4 to obtain the proofs of the respective sections.

Introduction.v was only created to have an introduction and overview table for index.html, it does not actually contain any Coq definitions.
