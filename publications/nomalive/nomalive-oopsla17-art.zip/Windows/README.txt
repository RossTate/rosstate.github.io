You need to install and set up a Windows installation as follows:

- Install .NET 4.6.2 Developer Pack
- Install Visual Studio c++ build tools 2015. Use a custom installation, the Windows 8 sdk is sufficient
- Install Racket 6.2
- Install Python 3.6.2; choose option to add to PATH, choose pip, tcl/tk, and the py launcher; precompile standard libraries and add to environment
- Add Racket installation directory to PATH
- Add the folder that contains vcvarsall.bat to the PATH. By default, that should be C:\Program Files (x86)\Microsoft Visual Studio 14.0\VC\ . You should be able to find it by looking at the start menu items that start the VS 2015 [...] Tools Command Prompts.
- Before running any individual benchmark, run setup.bat in the BENCHMARKS folder. run_all_benchmarks.bat runs it, too.