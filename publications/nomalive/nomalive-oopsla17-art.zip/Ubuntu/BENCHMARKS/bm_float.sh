#!/bin/bash

BMNAME="bm_float"
BMCOUNT=10

echo "Running Benchmark $BMNAME"

mkdir ./NG_$BMNAME/fullbackups
mv ./NG_$BMNAME/benchmark/*_full.csv ./NG_$BMNAME/fullbackups/
./Benchmark.exe -l ng-bash -r NG_$BMNAME -n $BMCOUNT -w
cp -f ./NG_$BMNAME/benchmark/*_full.csv ./ng_$BMNAME.csv

mkdir ./py_$BMNAME/fullbackups
mv ./py_$BMNAME/benchmark/*_full.csv ./py_$BMNAME/fullbackups/
./Benchmark.exe -l py3 -r py_$BMNAME -n $BMCOUNT -w
cp -f ./py_$BMNAME/benchmark/*_full.csv ./py_$BMNAME.csv

python3 plot.py ng_$BMNAME.png ng_$BMNAME.csv Nom
python3 plot.py py_$BMNAME.png py_$BMNAME.csv Python

echo "Benchmark $BMNAME complete"
