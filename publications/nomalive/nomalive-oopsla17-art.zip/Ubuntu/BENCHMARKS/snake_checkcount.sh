#!/bin/bash

BMNAME="Snake"

echo "Running Check-Counting Benchmark $BMNAME"

mkdir ./NG_snake/fullbackups
mv ./NG_snake/benchmark/*_full.csv ./NG_snake/fullbackups/
./Benchmark.exe -l ng-bash-stats -r NG_snake -n 1 -w --no-parallelization
cp NG_snake/benchmark/*_full.csv ./ng_snake_stats.csv

python3 process_stats.py snake_stats.png NG_snake statsout.txt 0

echo "Check-Counting Benchmark $BMNAME complete"