#!/bin/bash

BMNAME="bm_langstone"
BMCOUNT=10

echo "Running Benchmark $BMNAME"

mkdir ./NG_bm_nomstone/fullbackups
mv ./NG_bm_nomstone/benchmark/*_full.csv ./NG_bm_nomstone/fullbackups/
./Benchmark.exe -l ng-bash -r NG_bm_nomstone -n $BMCOUNT -w
cp -f ./NG_bm_nomstone/benchmark/*_full.csv ./ng_bm_nomstone.csv

mkdir ./py_bm_pystone/fullbackups
mv ./py_bm_pystone/benchmark/*_full.csv ./py_bm_pystone/fullbackups/
./Benchmark.exe -l py3 -r py_bm_pystone -n $BMCOUNT -w
cp -f ./py_bm_pystone/benchmark/*_full.csv ./py_bm_pystone.csv

python3 plot.py ng_bm_nomstone.png ng_bm_nomstone.csv Nom
python3 plot.py py_bm_pystone.png py_bm_pystone.csv Python

echo "Benchmark $BMNAME complete"
