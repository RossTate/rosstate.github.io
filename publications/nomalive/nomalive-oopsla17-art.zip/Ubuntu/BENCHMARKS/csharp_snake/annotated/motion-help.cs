using System;

public partial class Snake
{
	public static Posn NextHead(Posn p, Dir d)
	{
		if(d==Dir.Right)
		{
			// #"Right".Print();
			return Posn.Make(Posn.GetX(p)+1,Posn.GetY(p));
		}
		else if(d==Dir.Left)
		{
			// #"Left".Print();
			return Posn.Make(Posn.GetX(p)-1,Posn.GetY(p));
		}
		else if(d==Dir.Down)
		{
			// #"Down".Print();
			return Posn.Make(Posn.GetX(p),Posn.GetY(p)-1);
		}
		else
		{
			// # if(d==Dir::Up)
			// # {
				// # "Up".Print();
			// # }
			// # else
			// # {
				// # "?".Print();
			// # }
			return Posn.Make(Posn.GetX(p),Posn.GetY(p)+1);
		}
	}
	
	public static Snake Slither(Snake s)
	{
		Dir d = GetDir(s);
		return Snake.Make(d, PosnList.Cons(NextHead(PosnList.Car(GetSegs(s)), d), CutTail(GetSegs(s))));
	}
	
	public static Snake Grow(Snake s)
	{
		Dir d = GetDir(s);
		return Snake.Make(d, PosnList.Cons(NextHead(PosnList.Car(GetSegs(s)), d), GetSegs(s)));
	}
}