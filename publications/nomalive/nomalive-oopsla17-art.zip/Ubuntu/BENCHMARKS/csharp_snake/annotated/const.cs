using System;

public class Global
{
	public static int GRID_SIZE = 30;
	
	public static int BOARD_HEIGHT = 20;
	
	public static int BOARD_WIDTH = 30;
	
	public static int BOARD_HEIGHT_PIXELS = 600;
	
	public static int BOARD_WIDTH_PIXELS = 900;
	
	public static int SEGMENT_RADIUS = 15;
	
	public static int FOOD_RADIUS = 15;
}

public partial class World
{
	public static World WORLD = new World(
		Snake.Make(Dir.Right, PosnList.Cons(Posn.Make(5,3),null)),
		Posn.Make(8,12));
}