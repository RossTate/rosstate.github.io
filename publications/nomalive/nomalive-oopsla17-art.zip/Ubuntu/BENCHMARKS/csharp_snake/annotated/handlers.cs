using System;

public partial class World
{
	public static World HandleKey(World w, String ke)
	{
		if(ke == "w")
		{
			return ChangeDirection(w, Dir.Up);
		}
		else if(ke == "s")
		{
			return ChangeDirection(w, Dir.Down);
		}
		else if(ke == "a")
		{
			return ChangeDirection(w, Dir.Left);
		}
		else if(ke == "d")
		{
			return ChangeDirection(w, Dir.Right);
		}
		else
		{
			return w;
		}
	}
	
	public static bool GameOver(World w)
	{
		return Snake.WallCollide(GetSnake(w)) || Snake.SelfCollide(GetSnake(w));
	}
}