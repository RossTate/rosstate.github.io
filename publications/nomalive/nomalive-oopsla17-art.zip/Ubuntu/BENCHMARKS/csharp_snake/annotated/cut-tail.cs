using System;

public partial class Snake
{
	public static PosnList CutTail(PosnList segs)
	{
		PosnList r = PosnList.Cdr(segs);
		if(r==null)
		{
			return null;
		}
		else
		{
			return PosnList.Cons(PosnList.Car(segs), CutTail(r));
		}
	}
}