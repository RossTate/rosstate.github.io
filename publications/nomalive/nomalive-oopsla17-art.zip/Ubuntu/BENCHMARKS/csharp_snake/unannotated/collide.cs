using System;

public partial class Snake
{
	public static dynamic WallCollide(dynamic s)
	{
		return HeadCollide((dynamic)PosnList.Car((dynamic)GetSegs(s)));
	}
	
	public static dynamic HeadCollide(dynamic p)
	{
		return (dynamic)Posn.GetX(p) <= (dynamic)0 || (dynamic)Posn.GetX(p) >= (dynamic)Global.BOARD_WIDTH || (dynamic)Posn.GetY(p) <= (dynamic)0 || (dynamic)Posn.GetY(p) >= (dynamic)Global.BOARD_HEIGHT;
	}
	
	public static dynamic SelfCollide(dynamic s)
	{
		return SegsSelfCollide((dynamic)PosnList.Car((dynamic)GetSegs(s)), (dynamic)PosnList.Cdr((dynamic)GetSegs(s)));
	}
	
	public static dynamic SegsSelfCollide(dynamic p, dynamic segs)
	{
		if(segs == null)
		{
			return false;
		}
		else
		{
			if(Posn.Eq((dynamic)PosnList.Car(segs), p))
			{
				return true;
			}
			else
			{
				return SegsSelfCollide(p, (dynamic)PosnList.Cdr(segs));
			}
		}
	}
}