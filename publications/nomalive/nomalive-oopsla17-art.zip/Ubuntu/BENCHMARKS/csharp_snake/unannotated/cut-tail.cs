using System;

public partial class Snake
{
	public static dynamic CutTail(dynamic segs)
	{
		dynamic r = PosnList.Cdr(segs);
		if(r==null)
		{
			return null;
		}
		else
		{
			return PosnList.Cons((dynamic)PosnList.Car(segs), (dynamic)CutTail(r));
		}
	}
}