using System;

public partial class Snake
{
	public static dynamic NextHead(dynamic p, dynamic d)
	{
		if(d==Dir.Right)
		{
			// #"Right".Print();
			return Posn.Make((dynamic)Posn.GetX(p)+(dynamic)1,(dynamic)Posn.GetY(p));
		}
		else if(d==Dir.Left)
		{
			// #"Left".Print();
			return Posn.Make((dynamic)Posn.GetX(p)-(dynamic)1,(dynamic)Posn.GetY(p));
		}
		else if(d==Dir.Down)
		{
			// #"Down".Print();
			return Posn.Make((dynamic)Posn.GetX(p),(dynamic)Posn.GetY(p)-(dynamic)1);
		}
		else
		{
			// # if(d==Dir::Up)
			// # {
				// # "Up".Print();
			// # }
			// # else
			// # {
				// # "?".Print();
			// # }
			return Posn.Make((dynamic)Posn.GetX(p),(dynamic)Posn.GetY(p)+(dynamic)1);
		}
	}
	
	public static dynamic Slither(dynamic s)
	{
		dynamic d = GetDir(s);
		return Snake.Make(d, (dynamic)PosnList.Cons((dynamic)NextHead((dynamic)PosnList.Car((dynamic)GetSegs(s)), d), (dynamic)CutTail((dynamic)GetSegs(s))));
	}
	
	public static dynamic Grow(dynamic s)
	{
		Dir d = GetDir(s);
		return Snake.Make(d, (dynamic)PosnList.Cons((dynamic)NextHead((dynamic)PosnList.Car((dynamic)GetSegs(s)), d), (dynamic)GetSegs(s)));
	}
}