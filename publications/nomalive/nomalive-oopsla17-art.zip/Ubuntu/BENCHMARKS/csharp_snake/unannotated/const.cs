using System;

public class Global
{
	public static dynamic GRID_SIZE = 30;
	
	public static dynamic BOARD_HEIGHT = 20;
	
	public static dynamic BOARD_WIDTH = 30;
	
	public static dynamic BOARD_HEIGHT_PIXELS = 600;
	
	public static dynamic BOARD_WIDTH_PIXELS = 900;
	
	public static dynamic SEGMENT_RADIUS = 15;
	
	public static dynamic FOOD_RADIUS = 15;
}

public partial class World
{
	public static dynamic WORLD = new World(
		Snake.Make(Dir.Right, PosnList.Cons(Posn.Make(5,3),null)),
		Posn.Make(8,12));
}