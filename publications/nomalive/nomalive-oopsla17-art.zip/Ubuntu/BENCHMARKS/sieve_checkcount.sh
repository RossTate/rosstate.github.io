#!/bin/bash

BMNAME="Sieve"

echo "Running Check-Counting Benchmark $BMNAME"

mkdir ./NG_sieve/fullbackups
mv ./NG_sieve/benchmark/*_full.csv ./NG_sieve/fullbackups/
./Benchmark.exe -l ng-bash-stats -r NG_sieve -n 1 -w
cp ./NG_sieve/benchmark/*_full.csv ./ng_sieve_stats.csv

python3 process_stats.py sieve_stats.png NG_sieve statsout.txt 0

echo "Check-Counting Benchmark $BMNAME complete"
