class UnknownTypeError(Exception):
    pass
class UnexpectedTypeError(Exception):
    pass
class UnimplementedException(Exception):
    pass
class StaticTypeError(Exception):
    pass
class RuntimeTypeError(BaseException):
    pass
