def _exec(obj, globs=None, locs=None):
    exec obj in globs, locs
