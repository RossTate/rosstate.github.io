#!/bin/bash
cd BENCHMARKS
raco link benchmark-util
./bm_float.sh
./bm_go.sh
./bm_langstone.sh
./bm_nqueens.sh
./bm_spectralnorm.sh
./sieve.sh
./snake.sh
./sieve_checkcount.sh
./snake_checkcount.sh
