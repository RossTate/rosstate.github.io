# Generated an arbitrated resource description
import sys

size = 100

# Declarations and programs
dec = []
prog = []

for d in dec:
	print dec

for i in range(size):
	dec += ["new A" + str(i) + "r.("]
	dec += ["new A" + str(i) + "d.("]
	prog += ["*(A"+str(i)+"r!!; S!!; A"+str(i)+"d??)"]

# The channels
for d in dec:
	print d

# The controller
print "   *([ #A0r -> A0r??; A0d!!"
for i in range(size):
	print "     | #A" + str(i) + "r -> A" + str(i) + "r??; A" + str(i) + "d!!"
print "    ])"

# The users
for p in prog:
	print "|| " + p

# The shared resource
print "|| *(S??)"

# Close parens

for i in range(size*2):
	sys.stdout.write(')')
