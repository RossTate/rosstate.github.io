# Generates an arbitrairy size fifo
import sys

size = 50

dec = []
prog = []

for i in range(size):
	dec += ["new A" + str(i) + ".("]
	prog += ["*(A" + str(i) + "??; A" + str(i+1) + "!!)"]

for d in dec:
	print d

print "   *(I??; A0!!)"

for p in prog[0:-1]:
	print "|| " + p

print "|| *(A" + str(size-1) + "??; O!!)"

for i in range(size):
	sys.stdout.write(')')

print ""
