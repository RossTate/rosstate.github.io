# Generate a token-loop buffer style use of shared resources
import sys

size = 5

# Declarations and programs
dec = []
prog = []

for i in range(size):
	dec += ["new A" + str(i) + ".("]
	prog += ["*(A" + str(i) + "??; S!!; A" + str(i+1) + "!!)"]

for d in dec:
	print d

# Give the first one access to start with
print "   S!!; A0!!; *(A" + str(size-1) + "??; S!!; A0!!)" 

for p in prog[0:-1]:
	print "|| " + p

# The shared resource
print "|| *(S??)"

for i in range(size):
	sys.stdout.write(')')
